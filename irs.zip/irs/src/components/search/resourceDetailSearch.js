import React, { Component } from 'react';
import '../../../style_css/antd.css';
import $ from 'jquery';
import { Row, Col, Card, Button, Form,Layout } from 'antd';
import { Link } from "react-router-dom"
import { connect } from 'react-redux';
const FormItem = Form.Item;
const buttoncolor = {
  color: "#fff",
  background: "#4cd1c9",
  border: "#4cd1c9",
}
class ResourceDetailSearch extends Component {
  constructor(props) {
    super(props);
    this.state = {
      content: null,
      r_name: "",
      r_desc: "",
      r_key: "",
      rtype: "",
      grade: "",
      field: "",
      subject: "",
      difficulty: "",
      answer: "",
      create_time: "",
      file_url:null,
      resource:[]
    }
  }
  //获取资源详情
  getdataDetail() {
    const { resourceid } = this.props
    console.log('进入ResourceDetailSearchajax');
    console.log(resourceid);
    $.ajax({
      url: "/api_v1.1/knowledge_resource/resourceDetail_v1_1",
      type: "GET",
      dataType: "json",
      data: { "r_id": resourceid },
      success: function (data) {
        if (data.errorCode == "0") {
          console.log('成功获取该资源');
          console.log(data);
          console.log(data.msg);
          console.log(data.msg[0]);
          console.log(data.msg[0].r_name);
          this.setState({
            r_name: data.msg[0].r_name,
            r_desc: data.msg[0].r_desc,
            r_key: data.msg[0].r_key,
            rtype: data.msg[0].rtype,
            grade: data.msg[0].grade,
            field: data.msg[0].field,
            difficulty: data.msg[0].difficulty,
            answer: data.msg[0].answer,
            create_time: data.msg[0].create_time,
            subject: data.msg[0].subject,
            file_url: data.msg[0].file_url,
          });
        }
        else {
          console.log('资源不存在');
          this.setState({ resource: data.msg });
          console.log(this.state.resource);
        }

      }.bind(this),
      error: function (xhr, status, err) {
      }.bind(this)
    });
  }


  // componentWillReceiveProps() {
  //   this.getdata(); 
  // }
  render() {
    return (
      <Card style={{ height: '800px' }}>
         <Row gutter={18}>
          <Col span={8}>
             {/* <Card title="资源内容" >
            
               <img src={this.state.file_url} />
             </Card> */}
          </Col> 
          <Col span={18}>
            <Card title="资源详情" style={{ marginLeft: '200px' }}>
              <h3 style={{ paddingBottom: "15px" }}>资源名称：{this.state.r_name}</h3>
              <Form><FormItem label="资源描述"> <h3 style={{ paddingBottom: "15px" }}  dangerouslySetInnerHTML={{ __html: this.state.r_desc}}></h3></FormItem ></Form>
              <h3 style={{ paddingBottom: "15px" }}>关键字：{this.state.r_key}</h3>
              <h3 style={{ paddingBottom: "15px" }}>资源类型：{this.state.rtype}</h3>
              <h3 style={{ paddingBottom: "15px" }}>适用对象：{this.state.grade}</h3>
              <h3 style={{ paddingBottom: "15px" }}>适用领域：{this.state.field}</h3>
              <h3 style={{ paddingBottom: "15px" }}>学科：{this.state.subject}</h3>
              <h3 style={{ paddingBottom: "15px" }}>难度：{this.state.difficulty}</h3>
              <h3 style={{ paddingBottom: "15px" }}>答案：{this.state.answer}</h3>
              <h3 style={{ paddingBottom: "15px" }}>创建时间：{this.state.create_time}</h3>
            </Card>
          </Col>
        </Row>
        <Row gutter={24} style={{ marginTop: "50px" }}>
          <Col span={7}></Col>
          <Col span={3}>
            <Link to="/App/Search_Index/searchContent"><Button type="primary" size="large" style={buttoncolor}>返回</Button></Link>
          </Col>
          <Col span={14}>
            <Link to="/App/reviseResourceSearch"><Button type="primary" size="large" style={buttoncolor}>修改资源</Button></Link>
          </Col>
        </Row>
      </Card>
    );
  }
  componentDidMount() {
    this.getdataDetail();
  }
}

function mapStateToProps(state) {
  return {
    resourceid: state.search_module2.resourceid,
  };
}


function mapDispatchToProps(dispatch) {
  return {

  };
}

export default connect(
  mapStateToProps,
  mapDispatchToProps
)(ResourceDetailSearch);