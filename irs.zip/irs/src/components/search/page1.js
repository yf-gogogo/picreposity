import React, { Component } from 'react';
import { Link } from 'react-router-dom'
import { Row, Col, Layout, Button, Card, Icon, Form, message, Pagination, Breadcrumb, Tag, Select } from 'antd';
import 'antd/dist/antd.css';
import $ from 'jquery';
import PropTypes from "prop-types";
import moment from 'moment';
import { connect } from 'react-redux';
const FormItem = Form.Item;
const Option = Select.Option;
class Page1 extends Component {
  static contextTypes = {
    router: PropTypes.object
  }
  constructor(props, context) {
    super(props, context)
    this.state = {
      subject: null,
      allPages: -1,
      knowledgeInfo:[{}],
      knowledgeList:null,
      current: 1
    }
  }
  onChange = (page) => {
    console.log(page);
    $.ajax({
      url: "/api_v1.1/pagequery/querysubjectbypage_v1_1",
      type: "GET",
      dataType: "json",
      data: { "subject": this.state.subject, "count": 10, "page": page },
      success: function (data) {
        console.log('data222');
        console.log(data);
        this.setState({
          knowledgeInfo: data.msg,
          current: page
        });
      }.bind(this),
      error: function (xhr, status, err) {
      }.bind(this)
    });
  }
  handleClick() {
    $.ajax({
      url: "/api_v1.1/pagequery/querysubjectbypage_v1_1",
      type: "GET",
      dataType: "json",
      data: { "subject": this.state.subject, "count": 10, "page": 1 },
      success: function (data) {
        console.log('data222');
        console.log(data);
        this.setState({
          allPages: data.allpages,
          knowledgeInfo: data.msg
        });
      }.bind(this),
      error: function (xhr, status, err) {
      }.bind(this)
    });
  }

  subjectChange(e) { console.log(e); this.setState({ subject: e }); }

  render() {
    //检索知识点列表
     if (JSON.stringify(this.state.knowledgeInfo[0])=='{}') {
      // console.log(JSON.stringify(this.state.knowledgeInfo[0])=='{}');
      this.state.knowledgeList =this.state.knowledgeInfo.map(() => {
        return (
           <Row><p><Icon type="loading" />正在刷新中……</p></Row>
        );
      }); 
    }else{
      console.log(this.state.knowledgeInfo.length);
      this.state.knowledgeList = this.state.knowledgeInfo.map((v, i) => {
        console.log('this.state.knowledgeInfo.length22');
        return (
          <Card key={i}>
            <Row>{i + 1 + (this.state.current - 1) * 10}、{v.description}</Row>
          </Card>
        );
      });
    }

    return (
      <Layout>
        <Breadcrumb style={{ margin: '16px 0' }}>
          <Breadcrumb.Item>检索</Breadcrumb.Item>
          <Breadcrumb.Item>资源检索</Breadcrumb.Item>
        </Breadcrumb>
        <Row>
          <Form layout="inline">
            <Row>
              <Col span={4}></Col>
              <Col >
                <FormItem
                  label={<span>学科</span>}
                  labelCol={{ span: 11 }}
                  wrapperCol={{ span: 10 }}
                >
                  <Select style={{ width: 100 }} size='default' onChange={this.subjectChange.bind(this)}>
                    <Option value="数学">数学</Option>
                    <Option value="语文">语文</Option>
                    <Option value="英语">英语</Option>
                    <Option value="地理">地理</Option>
                    <Option value="政治">政治</Option>
                    <Option value="历史">历史</Option>
                    <Option value="物理">物理</Option>
                    <Option value="化学">化学</Option>
                    <Option value="生物">生物</Option>
                    <Option value="美术">美术</Option>
                    <Option value="体育">体育</Option>
                    <Option value="音乐">音乐</Option>
                    <Option value="历史与社会">历史与社会</Option>
                  </Select>
                </FormItem>
                <Button type="primary" onClick={this.handleClick.bind(this)}>检索</Button>
              </Col>
            </Row>
          </Form>
        </Row>
        <Row gutter={24}>
          <Col>
            <Card title="知识点列表" bordered={true} >
              {this.state.knowledgeList}
              <Pagination current={this.state.current} onChange={this.onChange} total={this.state.allPages * 10} />
            </Card>
          </Col>
        </Row>
      </Layout >
    );
  }
}
export default Page1;