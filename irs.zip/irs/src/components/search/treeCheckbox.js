import React, { Component } from 'react';
import $ from 'jquery';
import { Router, Route, hashHistory, IndexRoute, Redirect, IndexLink } from 'react-router';
import { Link, HashRouter } from 'react-router-dom'
import { Tabs, Icon, Form, Input, Button, Breadcrumb, Select, Radio, Layout, Card, Row, Col, Modal, Tree, Checkbox } from 'antd';
const { Header, Content, Footer, Sider } = Layout;
const TreeNode = Tree.TreeNode;
const FormItem = Form.Item;
const Option = Select.Option;

class treeCheckbox extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      content: false,
      treeData: [{ title: '数学', isLeaf: false }],
      TreeNodeData: [],
      checkedKeys: [],
      checkedNode: [],
      relationKnowledgeId: []
    }
  }

  onCheck = (checkedKey, e) => {
    this.state.checkedNode.push({ 'checked': e.checked, 'knowid': e.node.props.dataRef.knowid,'title':e.node.props.dataRef.title})
    for (let i = this.state.checkedNode.length; i >=0 ; i--) {
      //之所以要倒着遍历，是因为如果采用从前往后遍历的话，一个数组[1,2,3]通过splice删除index为0的数据之后，再次回到for循环，之前index为1的数据变为了便成为了index为0的数据，这样便少遍历了数据。
      //若倒着遍历，便可避开这个问题，对应数据即使删除了，也不会产生前移的问题。
      if (e.node.props.dataRef.knowid == this.state.checkedNode[i].knowid) {
        if(e.checked==false){
          this.state.checkedNode.splice(i,1);
        }
      }
    }
    this.setState({
      checkedKeys: checkedKey,
    });
  }

  renderTreeNodes = (data) => {
    return data.map((item) => {
      if (item.children) {
        return (
          <TreeNode title={item.title} key={item.key} dataRef={item}>
            {this.renderTreeNodes(item.children)}
          </TreeNode>
        );
      }
      return <TreeNode {...item} dataRef={item} />;
    });
  }
  onLoadData = (treeNode) => {
    return new Promise((resolve) => {
      if (treeNode.props.children) {
        resolve();
        return;
      }
      this.querySecondLayerRelation(treeNode.props.knowid);
      setTimeout(() => {
        treeNode.props.dataRef.children = this.state.TreeNodeData;
        this.setState({
          treeData: [...this.state.treeData],
        });
        resolve();
      }, 1000);
    });
  }
  querySecondLayerRelation(knowid) {
    $.ajax({
      url: "/api_v1.1/knowledge/querySecondLayerRelation",
      type: "GET",
      dataType: "json",
      data: { "knowid": knowid },
      success: function (data) {
        if (data.errorCode == 1) {
          console.log('该知识点没有下一层结构');
        }
        else {
          console.log('成功获取该知识点的下一层极结构');
          console.log(data);
          this.setState({ TreeNodeData: data.msg });
        }
      }.bind(this),
      error: function (xhr, status, err) {
      }.bind(this)
    });
  }
  componentWillMount() {
    $.ajax({
      url: "/api_v1.1/knowledge/queryFirstLayerRelation",
      type: "GET",
      dataType: "json",
      data: {
        keywords: '整数'
      },
      success: function (data) {
        console.log('data')
        console.log(data)
        if (data.errorCode == 0) {
          this.setState({
            treeData: data.msg
          });
        }
        else {
          console.log('第一步获取失败');
        }
      }.bind(this),
      error: function (xhr, status, err) {
      }.bind(this)
    });
  }
  checkSubmit() {
    let temp = [];
    for (let i = 0; i < this.state.checkedNode.length; i++) {
      temp.push(this.state.checkedNode[i].props.knowid)
    }
  }
  render() {
    return (
      <div style={{ paddingTop: '30px' }}>
        <Card style={{ height: '750px', paddingTop: '20px' }}>
          <Tree
            checkable
            checkStrictly
            onCheck={this.onCheck}
            checkedKeys={this.state.checkedKeys}
            loadData={this.onLoadData}
          >
            {this.renderTreeNodes(this.state.treeData)}
            <Button onClick={this.checkSubmit.bind(this)}>确定</Button>
          </Tree>
        </Card>
      </div>
    );
  }
}
export default treeCheckbox;