import React from 'react'
import echarts from 'echarts/lib/echarts' //必须
import 'echarts/lib/component/tooltip'
import 'echarts/lib/component/legend'
import 'echarts/lib/chart/pie'
import 'echarts/lib/chart/graph'
import { connect } from 'react-redux';
import PropTypes from "prop-types";
class MapSubject extends React.Component {
    static contextTypes = {
        router: PropTypes.object
    }
    constructor(props, context) {
        super(props, context)
        this.initPie = this.initPie.bind(this)
        this.state = {
            Display: "none",
        }
    }
    initPie() {
        const map_subject = {
            tooltip: {
                formatter: '{b}'
            },
            series: [
                {
                    name: '学科选择',
                    type: 'treemap',
                    //roam: 'move',
                    zoomToNodeRatio: 0,
                    nodeClick: false,//屏蔽节点点击移至中心
                    breadcrumb: {
                        show: false
                    },
                    label: {
                        normal: {
                            fontSize: 20
                        },
                        show: true,
                        formatter: '{b}'
                    },
                    color: [
                        '#c23531', '#314656', '#61a0a8', '#dd8668',
                        '#91c7ae', '#6e7074', '#61a0a8', '#bda29a',
                        '#44525d', '#c4ccd3'
                    ],
                    colorSaturation: [0.35, 0.5],
                    itemStyle: {
                        normal: {
                            gapWidth: 1,
                            borderWidth: 0.5,
                            borderWidthColorSaturation: 0.6,
                        }
                    },
                    data: [
                        {
                            value: 1,
                            name: '我的任务',
                        },
                        {
                            value: 1,
                            name: '个人信息',
                        },
                        {
                            value: 1,
                            name: '学习云服务平台',
                        }, {
                            value: 1,
                            name: '资源检索',

                        }, {
                            value: 1,
                            name: '统计分析',
                        },
                        {
                            value: 1,
                            name: '教材视图',
                        },
                        {
                            value: 1,
                            name: '我的地图',
                        },
                        {
                            value: 1,
                            name: '主题图',
                        },
                        {
                            value: 1,
                            name: '知识库',
                        },
                    ]
                }
            ]
        }
        var myChart = echarts.init(this.ID) //初始化echarts
        var TimeFn = null;   //用于兼容单双击的Timeout函数指针
        this.ID.oncontextmenu = function () {   //屏蔽原本右键“保存图片”等事件
            return false;
        }
        let props = this.props
        //设置options
        if (myChart.getOption() == undefined) {
            myChart.setOption(map_subject)
        }
        else myChart.setOption(myChart.getOption())
        window.onresize = function () {
            myChart.resize()
        }
        // 双击事件
        myChart.on('dblclick', dblClick.bind(this))
        function dblClick(param) {
            clearTimeout(TimeFn)
            const { mapType, type1 } = this.props;
            //,type2
            switch (param.data.name) {
                case '知识库': {
                    mapType({
                        type: 'mapType',
                        payload: {
                            mapType: '知识库',
                        }
                    });
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'repository',
                        }
                    })
                    this.context.router.history.push("/App/SelectSubject_Index");
                    break;
                }
                case '教材视图': {
                    mapType({
                        type: 'mapType',
                        payload: {
                            mapType: '标准地图',
                        }
                    });
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'map',
                        }
                    })
                    this.context.router.history.push("/App/SelectSubject_Index");
                    break;
                }
                case '我的地图': {
                    mapType({
                        type: 'mapType',
                        payload: {
                          mapType: '我的地图',
                        }
                      });
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'mytask',
                        }
                    });
                    this.context.router.history.push("/App/MapType_MyMap");
                    break;
                }
                case '主题图': {
                    mapType({
                        type: 'mapType',
                        payload: {
                          mapType: '主题图',
                        }
                      });
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'mytopicmap',
                        }
                    });
                    this.context.router.history.push("/App/MapType_TopMap");
                    break;
                }
                case '统计分析': {
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'statistics',
                        }
                    })
                    this.context.router.history.push("/App/Statistics_Index");
                    break;
                }
                case '资源检索': {
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'search',
                        }
                    });
                    this.context.router.history.push("/App/Search_Index"); 
                    break;
                }
                case '学习云服务平台':  {
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'zyk-yun',
                        }
                    });
                    window.location.href = 'http://zyk-yun.mypep.com.cn/app/resource/manage.php'; 
                    break;
                }
                case '个人信息': {
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'information',
                        }
                    });
                    this.context.router.history.push("/App/User_Index/MyInformation"); 
                    break;
                }
                case '我的任务': {
                    type1({
                        type: 'type1',
                        payload: {
                            mapType: 'mytask',
                        }
                    });
                    this.context.router.history.push("/App/MyTask"); 
                    break;
                }
               
            }
            // else{ this.context.router.history.push("https://www.baidu.com");} 
        }
    }
    componentDidMount() {
        this.initPie()

    }
    componentDidUpdate() {
        this.initPie()
    }
    render() {
        const { width = "100%", height = '700px' } = this.props
        return <div ref={ID => this.ID = ID} style={{ width, height }}></div>
    }
}
function mapStateToProps(state) {
    return {
    };
}
function mapDispatchToProps(dispatch) {
    return {
        //selectMapSubject: (state) => dispatch(state),
        mapType: (state) => dispatch(state),
        type1: (state) => dispatch(state),

    };
}
export default connect(
    mapStateToProps,
    mapDispatchToProps
)(MapSubject);
