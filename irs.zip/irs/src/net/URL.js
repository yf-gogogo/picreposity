const URL = {
    // 通过交互课程id获取题目列表
    getAllSubjectList:'http://202.114.33.117:8080/wsRESTfulService/mooc/interaction/getAllSubjectList'
}