var testdb = {
    "username": "root",
   /* "password": "Mstarc@2017",
    "database": "rks",
    "host": "192.168.71.201",*/
    "password": "123456",
    "database": "rks",
    "host": "192.168.71.23",
    "dialect": "mysql"
}



var path = {
    "single_url":"http://localhost:3000/uploads/",
    "batch_url":"http://localhost:3000/thumb/"
}

var vHost_Port = {
    "vhost":"192.168.71.201",
    "vport":8080
} 

var cors_setting={
    "enable_extra_login": true,
    "extra_login_path":"http://zyk-yun.mypep.com.cn/app/api/login_hs.php",
    "allow_orgin_host":"*",
}
module.exports = {
    testdb,
    path,
    cors_setting,
    vHost_Port,
};
