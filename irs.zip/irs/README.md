react-webpack-express
=====================

Boilerplate to start developing npm react components with webpack. Includes flux as npm module.


Usage
=====

```
git clone https://github.com/mixxen/react-webpack-express.git myapp
cd myapp
npm install
npm run build
npm run server
open http://localhost:3000
```
Use `npm start` to run webpack watch.

License
=======

MIT
