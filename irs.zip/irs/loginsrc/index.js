import React from 'react';
import ReactDOM from 'react-dom';
import Login from './Login.js';
ReactDOM.render(<Login/>, document.getElementById('react-container'));
// ReactDOM.render(<App/>, document.getElementById('react-container'));

